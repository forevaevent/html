<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file']) && isset($_POST['preferred_name'])) {
    $uploads_dir = 'uploads';
    if (!is_dir($uploads_dir)) {
        mkdir($uploads_dir, 0777, true);
    }

    // Sanitize preferred name
    $preferred_name = preg_replace('/[^a-zA-Z0-9-_]/', '_', $_POST['preferred_name']);
    $file_extension = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);

    // Ensure the file is an HTML file
    if ($file_extension !== 'html') {
        echo "<script>alert('Only HTML files are allowed.'); window.location.href = 'upload.php';</script>";
        exit();
    }

    // Handle file versioning
    $base_name = $preferred_name;
    $version = 1;

    while (file_exists("$uploads_dir/$base_name" . "_v$version.$file_extension")) {
        $version++;
    }

    $target_file = "$uploads_dir/$base_name" . "_v$version.$file_extension";

    if (move_uploaded_file($_FILES['file']['tmp_name'], $target_file)) {
        $download_url = 'download.php?file=' . urlencode($target_file);

        // Log file metadata
        $_SESSION['files'][] = [
            'name' => $preferred_name,
            'path' => $target_file,
            'size' => filesize($target_file),
            'date' => date('Y-m-d H:i:s'),
            'download_url' => $download_url
        ];

        // Log activity
        file_put_contents('logs.txt', "File uploaded: $target_file\n", FILE_APPEND);

        header('Location: upload.php');
        exit();
    } else {
        echo "<script>alert('File upload failed'); window.location.href = 'upload.php';</script>";
        exit();
    }
} else {
    echo "<script>alert('No file uploaded or preferred name missing'); window.location.href = 'upload.php';</script>";
    exit();
}
?>

<form action="process_upload.php" method="post" enctype="multipart/form-data">
    <input type="file" name="file" required>
    <input type="text" name="preferred_name" required placeholder="Enter your preferred name">
    <input type="email" name="email" placeholder="Enter your email address (optional)">
    <button type="submit">Upload File</button>
</form>