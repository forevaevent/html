<?php
session_start();

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: index.html');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload HTML File</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .upload-container {
            max-width: 500px;
            margin: auto;
            padding: 30px;
            border: 1px solid #e0e0e0;
            border-radius: 15px;
            background-color: #ffffff;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            position: relative;
            z-index: 1;
        }
        .activities {
            max-height: 400px;
            overflow-y: auto;
            margin-top: 20px;
            padding: 20px;
            border: 1px solid #e0e0e0;
            border-radius: 10px;
            background-color: #ffffff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            font-size: 24px;
            margin-bottom: 20px;
        }
        input[type="file"],
        input[type="text"] {
            margin: 10px 0;
            padding: 8px;
            width: 100%;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            padding: 10px 20px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #218838;
        }
        .download-link {
            margin-top: 20px;
            font-size: 16px;
        }
        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
        }
    </style>
</head>
<body>
    <h1>Upload HTML File</h1>
    <div class="upload-container">
        <form action="process_upload.php" method="post" enctype="multipart/form-data" style="max-width: 500px; margin: auto; padding: 30px; border: 1px solid #e0e0e0; border-radius: 15px; background-color: #f9f9f9; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1); font-family: 'Arial', sans-serif;">
            <h2 style="text-align: center; color: #4CAF50;">Secure File Transfer</h2>
            <p style="text-align: center; color: #555;">Easily upload your HTML files</p>
            <input type="file" name="file" required style="width: 100%; padding: 15px; margin-bottom: 15px; border-radius: 10px; border: 1px solid #ccc; background-color: #ffffff;">
            <input type="text" name="preferred_name" required placeholder="Enter preferred name (no extension)" style="width: 100%; padding: 15px; margin-bottom: 15px; border-radius: 10px; border: 1px solid #ccc; background-color: #ffffff;">
            <input type="email" name="email" placeholder="Optional: Your email address" style="width: 100%; padding: 15px; margin-bottom: 15px; border-radius: 10px; border: 1px solid #ccc; background-color: #ffffff;">
            <button type="submit" style="width: 100%; padding: 15px; background-color: #4CAF50; color: white; border: none; border-radius: 10px; cursor: pointer; font-size: 18px;">Upload File</button>
            <p style="text-align: center; margin-top: 15px; color: #555;">By uploading, you agree to our <a href="#" style="color: #4CAF50; text-decoration: none;">terms and conditions</a>.</p>
        </form>
    </div>

    <div class="activities">
        <h2>Uploaded Files</h2>
        <table>
            <tr>
                <th>Name</th>
                <th>Size</th>
                <th>Date</th>
                <th>Actions</th>
            </tr>
            <?php
            if (isset($_SESSION['files'])) {
                foreach ($_SESSION['files'] as $file) {
                    echo "<tr>
                            <td>{$file['name']}</td>
                            <td>{$file['size']} bytes</td>
                            <td>{$file['date']}</td>
                            <td>
                                <a href='download.php?file={$file['path']}'>Download</a>
                                <a href='delete.php?file={$file['path']}' onclick=\"return confirm('Are you sure?')\">Delete</a>
                            </td>
                          </tr>";
                }
            }
            ?>
        </table>
    </div>
</body>
</html>