<?php
session_start();

$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

if ($username === 'nifoaba' && $password === 'Success22') {
    $_SESSION['logged_in'] = true;
    header('Location: upload.php');
    exit();
} else {
    echo "<script>alert('Invalid username or password'); window.location.href = 'index.html';</script>";
    exit();
}
?>
